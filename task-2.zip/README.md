# To-Do List Web App

A simple and functional To-Do List app built using HTML, CSS, and Vanilla JavaScript.

## Features
- Add tasks
- Mark tasks as completed
- Remove tasks
- Instant UI updates without page reload

## How to Run
1. Clone the repository:
   ```bash
   git clone https://github.com/YOUR-USERNAME/todo-list-vanilla-js.git
   ```
2. Open the folder in VS Code
3. Right-click on `index.html` and select **"Open with Live Server"**

## Interview Questions Covered
- DOM Manipulation
- Event Listeners
- Arrow Functions
- Closures
- Difference between `==` and `===`, etc.

## License
MIT
